See [here](https://bsuece230l.github.io/classes/wk08/index.html) for the assignment and learning.

See [here](https://bsuece230l.github.io/classes/wk08/slides.html) for the slides.